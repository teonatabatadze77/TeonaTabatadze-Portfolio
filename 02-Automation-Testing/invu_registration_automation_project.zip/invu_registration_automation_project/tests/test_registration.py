from __future__ import annotations

import pytest

from pages.registration_page import RegistrationPage


@pytest.mark.registration
def test_registration_form_can_be_opened_and_filled(driver, settings):
    page = RegistrationPage(driver, settings.wait_timeout)
    email = settings.build_email()

    page.open_registration_form(settings.base_url)
    page.fill_registration_form(
        first_name=settings.first_name,
        last_name=settings.last_name,
        email=email,
        password=settings.password,
    )

    assert email in driver.page_source, "The generated email was not entered into the registration form as expected."


@pytest.mark.registration
@pytest.mark.optional_submission
def test_registration_submission(driver, settings):
    if not settings.submit_form:
        pytest.skip("Set INVU_SUBMIT_FORM=true to run the real registration submission test.")

    page = RegistrationPage(driver, settings.wait_timeout)
    email = settings.build_email()

    page.open_registration_form(settings.base_url)
    page.fill_registration_form(
        first_name=settings.first_name,
        last_name=settings.last_name,
        email=email,
        password=settings.password,
    )
    page.submit_registration()

    result = page.verify_submission_result(settings.base_url, email)
    assert result.success, result.message
