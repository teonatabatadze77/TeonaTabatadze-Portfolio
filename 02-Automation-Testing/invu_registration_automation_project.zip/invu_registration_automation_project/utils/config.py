from __future__ import annotations

import os
from dataclasses import dataclass
from datetime import datetime


@dataclass(frozen=True)
class Settings:
    base_url: str = os.getenv("INVU_BASE_URL", "https://invu.ge")
    wait_timeout: int = int(os.getenv("INVU_WAIT_TIMEOUT", "15"))
    headless: bool = os.getenv("INVU_HEADLESS", "false").lower() == "true"
    submit_form: bool = os.getenv("INVU_SUBMIT_FORM", "false").lower() == "true"
    first_name: str = os.getenv("INVU_FIRST_NAME", "Test")
    last_name: str = os.getenv("INVU_LAST_NAME", "User")
    password: str = os.getenv("INVU_PASSWORD", "TestPassword123!")
    email_domain: str = os.getenv("INVU_EMAIL_DOMAIN", "example.com")
    explicit_email: str | None = os.getenv("INVU_EMAIL")

    def build_email(self) -> str:
        if self.explicit_email:
            return self.explicit_email
        timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
        return f"testuser_{timestamp}@{self.email_domain}"
