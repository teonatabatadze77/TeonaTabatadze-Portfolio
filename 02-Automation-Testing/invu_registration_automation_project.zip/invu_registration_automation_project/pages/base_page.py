from __future__ import annotations

from typing import Iterable

from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.by import By
from selenium.webdriver.remote.webdriver import WebDriver
from selenium.webdriver.remote.webelement import WebElement
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait

Locator = tuple[str, str]


class BasePage:
    def __init__(self, driver: WebDriver, timeout: int = 15) -> None:
        self.driver = driver
        self.wait = WebDriverWait(driver, timeout)

    def open(self, url: str) -> None:
        self.driver.get(url)

    def find_first_visible(self, locators: Iterable[Locator], element_name: str) -> WebElement:
        last_error: Exception | None = None
        for by, locator in locators:
            try:
                return self.wait.until(EC.visibility_of_element_located((by, locator)))
            except TimeoutException as error:
                last_error = error
        raise TimeoutException(f"{element_name} was not found using any provided locator.") from last_error

    def click_first_clickable(self, locators: Iterable[Locator], element_name: str) -> None:
        last_error: Exception | None = None
        for by, locator in locators:
            try:
                element = self.wait.until(EC.element_to_be_clickable((by, locator)))
                element.click()
                return
            except TimeoutException as error:
                last_error = error
        raise TimeoutException(f"{element_name} was not clickable using any provided locator.") from last_error

    def fill_input(self, locators: Iterable[Locator], value: str, field_name: str) -> None:
        field = self.find_first_visible(locators, field_name)
        field.clear()
        field.send_keys(value)

    def is_any_text_present(self, candidates: list[str]) -> bool:
        page_source = self.driver.page_source.lower()
        return any(text.lower() in page_source for text in candidates)

    def current_url_contains_any(self, candidates: list[str]) -> bool:
        current_url = self.driver.current_url.lower()
        return any(text.lower() in current_url for text in candidates)
