from __future__ import annotations

from dataclasses import dataclass

from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.by import By

from pages.base_page import BasePage


@dataclass
class RegistrationResult:
    success: bool
    email: str
    message: str


class RegistrationPage(BasePage):
    LOGIN_LINKS = [
        (By.XPATH, "//a[@href='/login']"),
        (By.CSS_SELECTOR, "a[href='/login']"),
    ]

    CREATE_ACCOUNT_BUTTONS = [
        (By.ID, "create-account"),
        (By.XPATH, "//button[contains(., 'Create account')]"),
        (By.XPATH, "//button[contains(., 'Sign up')]"),
        (By.XPATH, "//button[contains(@class, 'font-medium') and @type='button']"),
    ]

    FIRST_NAME_INPUTS = [(By.ID, "firstName"), (By.NAME, "firstName")]
    LAST_NAME_INPUTS = [(By.ID, "lastName"), (By.NAME, "lastName")]
    EMAIL_INPUTS = [(By.ID, "email"), (By.NAME, "email"), (By.XPATH, "//input[@type='email']")]
    PASSWORD_INPUTS = [
        (By.ID, "password"),
        (By.NAME, "password"),
        (By.XPATH, "(//input[@type='password'])[1]"),
    ]
    CONFIRM_PASSWORD_INPUTS = [
        (By.ID, "confirmPassword"),
        (By.NAME, "confirmPassword"),
        (By.XPATH, "(//input[@type='password'])[2]"),
    ]

    SUBMIT_BUTTONS = [
        (By.XPATH, "//button[@type='submit']"),
        (By.XPATH, "//button[contains(., 'Create account') and @type='submit']"),
        (By.XPATH, "//button[contains(., 'Sign up') and @type='submit']"),
    ]

    SUCCESS_TEXTS = [
        "success",
        "verify",
        "dashboard",
        "welcome",
        "check your email",
        "email has been sent",
    ]

    ERROR_TEXTS = [
        "error",
        "already exists",
        "invalid",
        "required",
        "not valid",
        "failed",
    ]

    def open_registration_form(self, base_url: str) -> None:
        self.open(base_url)
        self.click_first_clickable(self.LOGIN_LINKS, "Login link")
        self.click_first_clickable(self.CREATE_ACCOUNT_BUTTONS, "Create account button")

    def fill_registration_form(self, first_name: str, last_name: str, email: str, password: str) -> None:
        self.fill_input(self.FIRST_NAME_INPUTS, first_name, "First name")
        self.fill_input(self.LAST_NAME_INPUTS, last_name, "Last name")
        self.fill_input(self.EMAIL_INPUTS, email, "Email")
        self.fill_input(self.PASSWORD_INPUTS, password, "Password")
        self.fill_input(self.CONFIRM_PASSWORD_INPUTS, password, "Confirm password")

    def submit_registration(self) -> None:
        self.click_first_clickable(self.SUBMIT_BUTTONS, "Submit button")

    def verify_submission_result(self, base_url: str, email: str) -> RegistrationResult:
        try:
            self.wait.until(lambda driver: driver.current_url != f"{base_url}/login")
        except TimeoutException:
            pass

        if self.current_url_contains_any(["dashboard", "verify", "success"]):
            return RegistrationResult(
                success=True,
                email=email,
                message=f"Registration submission looks successful. Current URL: {self.driver.current_url}",
            )

        if self.is_any_text_present(self.SUCCESS_TEXTS):
            return RegistrationResult(
                success=True,
                email=email,
                message="Registration submission completed and the page shows a success-related indicator.",
            )

        if self.is_any_text_present(self.ERROR_TEXTS):
            return RegistrationResult(
                success=False,
                email=email,
                message="Registration form was submitted, but the page shows a validation or error message.",
            )

        return RegistrationResult(
            success=False,
            email=email,
            message=(
                "Registration form was submitted, but no clear success indicator was found. "
                "Check locators and expected post-submit behavior on the site."
            ),
        )
